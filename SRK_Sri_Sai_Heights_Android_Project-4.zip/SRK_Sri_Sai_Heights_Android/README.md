# SRK's Sri Sai Heights Android App

Android wrapper for the existing SRK's Sri Sai Heights Firebase web app.

## Build without a PC
Upload the contents of this project to the public GitHub repository `govindareddy04-cyber/srks-sri-sai-heights`, including `.github/workflows/build-apk.yml`.
GitHub Actions will build `app-debug.apk`. Open the repository's **Actions** tab, select **Build Android APK**, open the completed run, and download the artifact **SRK-Sri-Sai-Heights-debug-apk** from the Android phone.
