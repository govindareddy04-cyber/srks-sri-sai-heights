# SRK's Sri Sai Heights Android App

Android wrapper for the SRK's Sri Sai Heights resident/admin web app.

## Current behavior
- App opens directly to the Resident login.
- Resident login uses Flat Number + PIN from Firestore.
- Admin is accessed from the Resident login screen using **Admin Login**.
- Admin now uses Firebase Authentication email + password instead of the old hard-coded PIN.
- Admin can return to Resident login.

## Firebase setup for Admin
In Firebase Console for project `srk-sri-sai-heights`:
1. Authentication -> Sign-in method -> enable **Email/Password**.
2. Authentication -> Users -> Add user.
3. Create the admin email/password you want to use in the app.
4. Do not put the password in this repository.

Note: Firebase Authentication protects the Admin login UI. For full backend security, Firestore Security Rules should also require authenticated/admin users before production use.
